require 'SandboxVars'

SandboxVars.ZomboMax = {
    FatigueReduction = 0.3,
    EnableAddiction = true,
    AddictionChance = 10,
    SpawnChance = "Normal"
}