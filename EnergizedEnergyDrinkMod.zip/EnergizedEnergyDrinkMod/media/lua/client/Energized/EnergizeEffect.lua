local function EnergizePlayer(player)
    if player:getStats():getFatigue() > 0.2 then
        player:getStats():setFatigue(math.max(0, player:getStats():getFatigue() - SandboxVars.ZomboMax.FatigueReduction))
    end
    if player:isAsleep() then
        player:forceAwake()
    end
    if SandboxVars.ZomboMax.EnableAddiction and ZombRand(100) < SandboxVars.ZomboMax.AddictionChance then
        player:getModData().ZomboMaxAddicted = true
    end
end

Events.OnEat.Add(function(food, player)
    if food:getType() == "ZomboMax" then
        EnergizePlayer(player)
    end
end)